var counter=function(arr){
    return 'There are' + arr.length + 'elements in this array';
};

module.exports= counter;