var counter=require('./count');


console.log(counter(['shaun', 'crystal', 'ryu']));